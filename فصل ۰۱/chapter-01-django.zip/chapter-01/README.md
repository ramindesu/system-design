# جزوهٔ عملی System Design با Python و Django

این مجموعه فصل‌به‌فصل آماده می‌شود. نسخهٔ آمادهٔ فعلی **فصل ۱** است: توضیح فارسی، مثال Read Replica، Cache، Transaction، صف، Session، رشد سرورها و تمرین با پاسخ.

## از کجا شروع کنم؟

1. فایل `01-scale-from-zero.html` را در مرورگر باز کن؛ متن راست‌به‌چپ و کد چپ‌به‌راست است. فهرست کناری به بخش‌ها می‌رود و دکمهٔ چاپ برای گرفتن PDF از مرورگر وجود دارد.
2. بخش «اجرا و آزمایش عملی» را دنبال کن. Python 3.12 پیشنهاد می‌شود؛ پروژه با همین نسخه و Django 5.2.18 بررسی شده است.
3. از پوشهٔ `lab` پروژه را اجرا کن. برای شروع PostgreSQL، Redis، Docker یا Celery لازم نیست.

## چه چیزی قابل اجراست؟

پروژهٔ `lab` مدل، Migration، Router، Service، API، دو Command و ۱۵ تست دارد. دو SQLite مستقل و کپی دستی داده برای مشاهدهٔ Lag استفاده می‌شوند. این شبیه‌سازی **Replication واقعی PostgreSQL نیست**.

نمونهٔ اتصال PostgreSQL در `lab/config/postgres_settings.py` وجود دارد. برای آن باید کلاستر Primary/Standby آماده، متغیرهای اتصال و بستهٔ `psycopg[binary]` داشته باشی. راه‌اندازی خود Replication و تست Row Lock/Failover در این بسته انجام نشده است. Cache پیش‌فرض LocMem مخصوص اجرای آموزشی است؛ چند Worker به Cache مشترک نیاز دارند.

نمونه‌های Nginx، Redis و Celery داخل جزوه نقطهٔ اتصال برنامه به زیرساخت را توضیح می‌دهند؛ در تست‌های SQLite اجرا نشده‌اند. تنظیمات پروژه برای توسعهٔ محلی‌اند، نه Deploy عمومی.

## وضعیت فصل‌ها

| فصل | عنوان | وضعیت |
|---|---|---|
| ۱ | Scale From Zero To Millions Of Users | جزوهٔ مفصل و آزمایشگاه آماده |
| ۲ | Back-of-the-envelope Estimation | پیش‌نویس؛ نیازمند بسط فصل‌به‌فصل |
| ۳ | A Framework For System Design Interviews | پیش‌نویس |
| ۴ | Design A Rate Limiter | پیش‌نویس |
| ۵ | Design Consistent Hashing | پیش‌نویس |
| ۶ | Design A Key-Value Store | پیش‌نویس |
| ۷ | Design A Unique ID Generator In Distributed Systems | پیش‌نویس |
| ۸ | Design A URL Shortener | پیش‌نویس |
| ۹ | Design A Web Crawler | پیش‌نویس |
| ۱۰ | Design A Notification System | پیش‌نویس |
| ۱۱ | Design A News Feed System | پیش‌نویس |
| ۱۲ | Design A Chat System | پیش‌نویس |
| ۱۳ | Design A Search Autocomplete System | پیش‌نویس |
| ۱۴ | Design YouTube | پیش‌نویس |
| ۱۵ | Design Google Drive | پیش‌نویس |
| ۱۶ | The Learning Continues | پیش‌نویس؛ تمرین تکمیلی |

منبع مفاهیم، نسخهٔ موجود از کتاب Alex Xu در پوشهٔ Books است. پیاده‌سازی‌ها و تمرین‌ها برای این جزوه نوشته شده‌اند؛ ترجمهٔ لفظ‌به‌لفظ کتاب یا کد ارائه‌شده توسط نویسنده نیستند. جزئیات API با مستندات رسمی لینک‌شده در فصل تطبیق داده شده است.
